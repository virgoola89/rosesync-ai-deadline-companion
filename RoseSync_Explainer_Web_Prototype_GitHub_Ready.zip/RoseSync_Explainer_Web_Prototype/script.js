(()=>{
  'use strict';
  const $=(id)=>document.getElementById(id);
  const all=(selector)=>Array.from(document.querySelectorAll(selector));
  const storageKey='rosesync-showcase-v6';
  const roseInfo={
    pink:{label:'Pink rose',meaning:'Growth, kindness & steady self-development.'},
    red:{label:'Red rose',meaning:'Passion, courage & determination.'},
    white:{label:'White rose',meaning:'Clarity, focus & fresh beginnings.'},
    yellow:{label:'Yellow rose',meaning:'Optimism, creative energy & friendship.'},
    lavender:{label:'Lavender rose',meaning:'Imagination, wonder & fresh possibilities.'}
  };
  const stageInfo=[{key:'seed',name:'SEED'},{key:'sprout',name:'SPROUT'},{key:'young',name:'YOUNG STEM'},{key:'bud',name:'ROSEBUD'},{key:'opening',name:'OPENING BLOOM'},{key:'bloom',name:'FULL BLOOM'}];
  const weatherInfo={sunny:'☀ Sunny',cloudy:'☁ Cloudy',rainy:'☂ Rainy',night:'☾ Night'};
  const defaultTasks=[{id:1,text:'Outline the first version',done:false},{id:2,text:'Review the next milestone',done:false}];
  const defaultState={rose:'pink',duration:14,weather:'sunny',project:'My creative project',energy:'focused',day:0,tasks:defaultTasks};
  let state=readState();
  function readState(){
    try{
      const parsed=JSON.parse(localStorage.getItem(storageKey)||'null');
      if(!parsed||typeof parsed!=='object')return structuredCloneSafe(defaultState);
      const s={...structuredCloneSafe(defaultState),...parsed};
      if(!roseInfo[s.rose])s.rose='pink';
      if(!weatherInfo[s.weather])s.weather='sunny';
      if(![14,30,90,180,365].includes(s.duration))s.duration=14;
      if(typeof s.project!=='string')s.project=defaultState.project;
      if(!Array.isArray(s.tasks))s.tasks=structuredCloneSafe(defaultTasks);
      s.tasks=s.tasks.filter(t=>t&&typeof t.text==='string').slice(0,6).map((t,i)=>({id:Number(t.id)||i+1,text:t.text.slice(0,75),done:!!t.done}));
      s.day=Math.max(0,Math.min(s.duration,Number(s.day)||0));
      return s;
    }catch(_){return structuredCloneSafe(defaultState)}
  }
  function structuredCloneSafe(v){return JSON.parse(JSON.stringify(v))}
  function save(){try{localStorage.setItem(storageKey,JSON.stringify(state))}catch(_){/* local storage may be disabled */}}
  function timeProgress(){return Math.min(1,Math.max(0,state.day/state.duration))}
  function taskProgress(){return state.tasks.length?state.tasks.filter(t=>t.done).length/state.tasks.length:0}
  function bloomProgress(){return Math.round((timeProgress()*.55+taskProgress()*.45)*100)}
  function growthStage(){
    if(state.day>=state.duration)return 5;
    const p=bloomProgress();
    if(p>=90)return 5;if(p>=71)return 4;if(p>=47)return 3;if(p>=25)return 2;if(p>=9)return 1;return 0;
  }
  function deadlineDate(){
    const d=new Date(); d.setHours(12,0,0,0);
    const duration=state.duration;
    if(duration===14)d.setDate(d.getDate()+14);
    else if(duration===365)d.setFullYear(d.getFullYear()+1);
    else {
      const months=duration===30?1:duration===90?3:6;
      const targetDay=d.getDate(); d.setDate(1); d.setMonth(d.getMonth()+months);
      const limit=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();
      d.setDate(Math.min(targetDay,limit));
    }
    return d;
  }
  function actualTotalDays(){
    const now=new Date();now.setHours(12,0,0,0);
    return Math.max(1,Math.round((deadlineDate()-now)/86400000));
  }
  function previewDate(){const d=new Date();d.setHours(12,0,0,0);d.setDate(d.getDate()+Math.min(state.day,actualTotalDays()));return d.toLocaleDateString('en-US',{weekday:'long',month:'short',day:'numeric'}).toUpperCase()}
  function remainingDays(){return Math.max(0,Math.round(actualTotalDays()*(1-state.day/state.duration)))}
  function labelRose(){const info=roseInfo[state.rose];const box=$('rose-meaning');box.querySelector('strong').textContent=info.label;box.querySelector('small').textContent=info.meaning}
  function paintChoices(){
    all('[data-rose]').forEach(b=>{const v=b.dataset.rose===state.rose;b.classList.toggle('active',v);b.setAttribute('aria-pressed',String(v))});
    all('[data-duration]').forEach(b=>{const v=Number(b.dataset.duration)===state.duration;b.classList.toggle('active',v);b.setAttribute('aria-pressed',String(v))});
    all('[data-weather]').forEach(b=>{const v=b.dataset.weather===state.weather;b.classList.toggle('active',v);b.setAttribute('aria-pressed',String(v))});
    all('[data-energy]').forEach(b=>{const v=b.dataset.energy===state.energy;b.classList.toggle('active',v);b.setAttribute('aria-pressed',String(v))});
  }
  function paintTasks(){
    const tasks=$('todo-list');tasks.replaceChildren();
    state.tasks.forEach((task)=>{
      const label=document.createElement('label');label.className='todo-row'+(task.done?' is-done':'');
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.checked=task.done;checkbox.dataset.taskId=String(task.id);checkbox.setAttribute('aria-label','Complete '+task.text);
      const span=document.createElement('span');span.textContent=task.text;
      label.append(checkbox,span);tasks.append(label);
    });
    const phone=$('phone-tasks');phone.replaceChildren();
    state.tasks.slice(0,2).forEach(task=>{
      const line=document.createElement('div');line.className='phone-focus-line'+(task.done?' complete':'');
      const check=document.createElement('span');check.className='tiny-box';check.textContent=task.done?'✓':'';
      const text=document.createElement('span');text.textContent=task.text;
      line.append(check,text);phone.append(line);
    });
    if(!state.tasks.length){
      const line=document.createElement('div');line.className='phone-focus-line';line.textContent='Your next small step belongs here.';phone.append(line);
    }
    $('focus-count').textContent=state.tasks.filter(t=>t.done).length+' / '+state.tasks.length;
  }
  function paintPhone(){
    const step=stageInfo[growthStage()];
    const src='assets/stages/'+state.rose+'/'+step.key+'.webp';
    const rose=$('phone-rose');if(!rose.getAttribute('src')||!rose.getAttribute('src').endsWith(src))rose.src=src;
    rose.alt=roseInfo[state.rose].label+' in the '+step.name.toLowerCase()+' stage';
    $('phone').dataset.weather=state.weather;
    $('phone-date').textContent=previewDate();
    $('phone-project').textContent=(state.project.trim()||'My creative project').slice(0,54);
    $('days-left').textContent=remainingDays();
    $('countdown-unit').textContent=remainingDays()===0?'deadline day':remainingDays()===1?'day left':'days left';
    $('phone-stage').textContent=step.name+' · DAY '+(state.day+1);
    $('phone-weather').textContent=weatherInfo[state.weather];
    $('phone-bloom').textContent=bloomProgress()+'% bloom';
    $('phone-meter-fill').style.width=bloomProgress()+'%';
    $('day-slider').max=state.duration;
    $('day-slider').value=state.day;
    $('day-label').textContent='Day '+(state.day+1)+' of '+(state.duration+1);
  }
  function boostText(){
    const first=state.tasks.find(t=>!t.done)?.text||'check your final result';
    switch(state.energy){
      case 'stuck':return `Start smaller. Open “${first}” and give it just five minutes. Don't solve the entire project right now.`;
      case 'tired':return `Make today lighter. If all you do is one gentle step toward “${first}”, that still counts. Take a real break too.`;
      case 'inspired':return `You've got momentum. Write down the best new idea, then turn one part of “${first}” into something you can test.`;
      default:return `You're moving. Pick “${first}” and give it 20 minutes of real attention. The rest can wait.`;
    }
  }
  function paint(){paintChoices();labelRose();paintTasks();paintPhone();$('boost-response').textContent=boostText();save()}
  all('[data-rose]').forEach(b=>b.addEventListener('click',()=>{state.rose=b.dataset.rose;paint()}));
  all('[data-weather]').forEach(b=>b.addEventListener('click',()=>{state.weather=b.dataset.weather;paint()}));
  all('[data-duration]').forEach(b=>b.addEventListener('click',()=>{state.duration=Number(b.dataset.duration);state.day=Math.min(state.day,state.duration);paint()}));
  all('[data-energy]').forEach(b=>b.addEventListener('click',()=>{state.energy=b.dataset.energy;paint()}));
  $('project-name').value=state.project;
  $('project-name').addEventListener('input',e=>{state.project=e.target.value;paintPhone();save()});
  $('day-slider').addEventListener('input',e=>{state.day=Math.round(Number(e.target.value));paintPhone();save()});
  $('todo-list').addEventListener('change',e=>{if(e.target.matches('input[type="checkbox"][data-task-id]')){const found=state.tasks.find(t=>t.id===Number(e.target.dataset.taskId));if(found)found.done=e.target.checked;paint()}});
  $('add-task-form').addEventListener('submit',e=>{e.preventDefault();const input=$('new-task'),v=input.value.trim();if(!v)return;if(state.tasks.length>=6){input.setCustomValidity('This preview supports up to six tasks.');input.reportValidity();setTimeout(()=>input.setCustomValidity(''),100);return}state.tasks.push({id:Math.max(0,...state.tasks.map(t=>t.id))+1,text:v.slice(0,75),done:false});input.value='';paint()});
  const menu=$('menu-toggle'),nav=$('main-nav');menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',open?'Close navigation':'Open navigation')});
  all('.main-nav a').forEach(link=>link.addEventListener('click',()=>{nav.classList.remove('open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','Open navigation')}));
  paint();
})();
