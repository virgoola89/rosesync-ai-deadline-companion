# RoseSync | Interactive Product Showcase

A static, responsive website that presents the **RoseSync** idea, explains how the system is designed, describes the build journey, shows what users receive, and includes a working lock-screen preview.

## Open it

Double-click `index.html` in a browser. No installation, account, secret, or build step is needed. The 35 rose images are included locally.

Or publish the *contents* of this directory to GitHub Pages:

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, `assets/`, `docs/`, and `README.md` into the repository root.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, `main`, and `/(root)`.
5. Visit `https://YOUR_USERNAME.github.io/YOUR_REPOSITORY/` after deployment.

This site can also be deployed to any static website host.

## What works in this release

- Choose Red, Pink, White, Yellow, or Lavender Rose.
- Select a journey of 2 weeks, 1 month, 3 months, 6 months, or 1 year.
- Rename the sample project and add or complete tasks.
- Use a timeline slider to preview growth from seed through full bloom.
- Change the visual atmosphere: Sunny, Cloudy, Rainy, Night.
- See sample Bloom Boost suggestions for Focused, Stuck, Tired, and Inspired.
- Keep demo preferences in local browser storage.
- Read the system model, build story, and user benefits.

## What this prototype does not do

This **showcase is static**. It doesn't call Gemini, use live location/weather, support accounts, store data on a server, or set the actual Android or iOS lock screen. The phone is a browser-based visual preview. The Bloom Boost examples are rule-based. The original RoseSync backend and Android roadmap are described as separate integration stages, not silently presented as working services in this website.

## Files

- `index.html`: landing page, sections, live preview structure
- `styles.css`: responsive cinematic editorial theme
- `script.js`: demo state, timeline, weather, checklist, Bloom Boost
- `assets/roses/`: five photorealistic rose color illustrations
- `assets/stages/`: six stages for each rose color (30 images)
- `docs/SYSTEM_OVERVIEW.md`: design and integration notes

## Accessibility and privacy

Use the keyboard to navigate the demo controls. The website includes descriptive image text and a reduced-motion stylesheet. Demo choices are stored in localStorage, if permitted. No location is requested, and no external analytics or API keys are used. External Google Fonts are optional; the site falls back to local fonts.

**Core belief:** AI can be a supportive goal partner, not simply a response engine. The user always owns the goal.
