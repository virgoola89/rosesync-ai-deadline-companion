# RoseSync System Overview

## Product idea

RoseSync pairs a deadline planner with a photographic rose that grows as time passes and meaningful work is completed. A clean daily focus area sits on a lock-screen concept. Optional AI planning and weather data give the experience more context.

## Concept flow

1. Choose one of five rose colors.
2. Choose a deadline range (2 weeks, 1 month, 3 months, 6 months, 1 year).
3. Enter a project name and rough milestones.
4. Review suggested daily tasks and mark tasks complete.
5. See a growth-stage visualization, countdown, and minimal focus list.
6. When feeling stuck, ask Bloom Boost for a simpler next move.

## Five roses

- Pink: growth, kindness, self-development.
- Red: passion, courage, determination.
- White: clarity and new beginnings.
- Yellow: optimism and creative energy.
- Lavender: imagination and possibility.

## Visual stages

`seed → sprout → young → bud → opening → bloom`

The demo uses a blend of time progress (55%) and task completion (45%) as a visual approximation. At the previewed deadline, it shows the full-bloom stage. This is a concept rule, not a biological growth model or tested productivity metric.

## Architecture

```text
User setup (rose, project, deadline, tasks)
  → progress engine (days remaining + tasks complete)
  → stage selector (six local rose assets)
  → visual renderer (weather atmosphere + lock screen)
```

A connected version could extend the flow:

```text
Web/Android client
  ↔ persistent project database
  ↔ secure Node.js / Express API
      ↔ Gemini planning and Bloom Boost
      ↔ weather provider (opt-in geolocation)
  ↔ Android wallpaper renderer / update scheduler
```

The Gemini API key must remain server-side. Location permission must be requested before looking up local conditions. A static web page cannot write directly to the system lock screen. Native Android integration is a separate development stage.

## What is implemented here

Interactive HTML/CSS/JavaScript, five rose choices, 30 photorealistic growth images, timeline slider, demo weather modes, sample checklist, sample Bloom Boost, and localStorage persistence.

## Planned future work

- Secure Gemini milestone suggestions and grounding/references.
- Project-level database and authentication.
- Opt-in live weather and user-controlled refresh behavior.
- Native Android app to apply generated wallpaper as the lock-screen background.
- Device-specific testing, battery policy validation, and accessibility review.
